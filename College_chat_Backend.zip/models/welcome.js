// const mongoose = require("mongoose")
// const welcome =  mongoose.Schema({
//     email : {
//         type : String,
//         require: true,
//         unique: true
//     },
//     password: {
//         type:String,
//     },
//     name :{
//         type: String,
//     },
//     phone : {
//         type: Number,
//     }
// })
// module.exports= mongoose.model("welcome", welcome)